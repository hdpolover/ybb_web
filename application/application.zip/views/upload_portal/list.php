<div class="container-fluid">

    <br>
    <div class="card bg-light text-black shadow">
        <div class="card-header py-3">
            <h5 style="color: black;"><strong>The 5th Istanbul Youth Summit Delegate</strong></h5>
        </div>
        <div class="card-body" style="padding: 20px;">
            <div class="row">
                <h5 style="color: black; margin-left: 20px;"><?= $full_name; ?></h5>
            </div>
            <div class="row">
                <h5 style="color: black; margin-left: 20px;"><?= $institution; ?></h5>
            </div>
        </div>
    </div>
    <br>
    <div class="card bg-light text-black shadow">
        <div class="card-body">
            <div class="row">
                <div class="col-9">
                    <h5 style="color: black;"><strong>Agreement Form</strong></h5>
                </div>
                <div class="col-3">
                    <a href="<?= base_url(); ?>" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</a>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="card bg-light text-black shadow">
        <div class="card-body">
            <div class="row">
                <div class="col-9">
                    <h5 style="color: black;"><strong>Payment Fee Batch 1</strong></h5>
                    <div class="text-black small">2.000.000 IDR / 140 USD</div>
                </div>
                <div class="col-3">
                    <a href="<?= base_url(); ?>assets/img/docs/LETTER_OF_AGREEMENT.pdf" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</a>
                </div>
            </div>
        </div>
    </div>
    <br>
    <br>
    <br>
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->


</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- End of Main Content -->