<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Upload_portal extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('doc_management_model', 'doc_management');
    }

    public function index()
    {
        $data['title'] = 'Upload Portal';
        $this->load->view('templates/summit_docs_header', $data);
        $this->load->view('upload_portal/index');
        $this->load->view('templates/summit_docs_footer');
    }

    public function result()
    {
        $email = $this->input->post('email');
        $data['title'] = 'Upload Portal';
        $res = $this->doc_management->get_data_by_email($email);

        $full_name = $res[0]['full_name'];
        $institution = $res[0]['institution'];
        $status = $res[0]['status'];

        if ($full_name == null || $status < 2) {
            $this->session->set_flashdata('message', '<div class ="alert alert-danger" style="text-align-center" role ="alert">Sorry. We can\'t seem to find an eligible 5th Istanbul Youth Summit delegate for the submitted email!</div>');
            redirect('upload_portal');
        } else {
            $data['title'] = 'Upload Portal';
            $data['full_name'] = $full_name;
            $data['institution'] = $institution;

            $this->load->view('templates/summit_docs_header', $data);
            $this->load->view('upload_portal/list', $data);
            $this->load->view('templates/summit_docs_footer');
        }
    }
}
